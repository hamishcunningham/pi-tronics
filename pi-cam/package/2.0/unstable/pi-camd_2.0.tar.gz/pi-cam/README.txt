Pi-Cam: a Simple Raspberry Pi Camera Daemon

This tree contains the code for a simple daemon for the Raspi camera. The
implementation is based on SimBaMon -- the simple battery monitor daemon --
see ../simbamon/README.txt

For more information surf on over to http://pi.gate.ac.uk/

The code is copyright Hamish Cunningham and the University of Sheffield and is
licenced under GPL 3 or any later version.
