import smbus

VERSION=0.2
# for mopi firmware v3.03
FIRMMAJ=3
FIRMMINR=3
READTRIES=3

class mopiapi():
	device = 0xb

	def __init__(self, i2cbus = 1):
		self.bus = smbus.SMBus(i2cbus)
		[maj, minr] = self.getFirmwareVersion()
		if maj != FIRMMAJ or minr != FIRMMINR:
			raise Exception("Version mis-match between API and MoPi. Got %i.%02i, expected %i.%02i." % (maj, minr, FIRMMAJ, FIRMMINR))

	def getStatus(self):
		return self.readWord(0b00000000)

	def getVoltage(self, input=0):
		if input == 1:
			return self.readWord(0b00000101) # 5
		elif input == 2:
			return self.readWord(0b00000110) # 6
		else:
			return self.readWord(0b00000001)

	# returns an array of 3 integers: max, mid, min (mV)
	def readConfig(self, input=0):
		if input == 1:
			data = self.bus.read_i2c_block_data(self.device, 0b00000111) # 7
		elif input == 2:
			data = self.bus.read_i2c_block_data(self.device, 0b00001000) # 8
		else:
			data = self.bus.read_i2c_block_data(self.device, 0b00000010)
		data2 = []
		# & 127 for leading bit, unfortunately on the LSB this is a bad idea...
		data2.append(((data[0] & 127) << 8) + data[1])
		data2.append(((data[2] & 127) << 8) + data[3])
		data2.append(((data[4] & 127) << 8) + data[5])
		return data2

	# takes an array of 3 integers: max, mid, min (mV)
	def writeConfig(self, battery, input=0):
		data = [
			battery[0] >> 8, battery[0] & 0xff, \
			battery[1] >> 8, battery[1] & 0xff, \
			battery[2] >> 8, battery[2] & 0xff, \
			]
		if input == 1:
			self.bus.write_i2c_block_data(self.device, 0b00000111, data) # 7
		elif input == 2:
			self.bus.write_i2c_block_data(self.device, 0b00001000, data) # 8
		else:
			self.bus.write_i2c_block_data(self.device, 0b00000010, data)

	def setPowerOnDelay(self, poweron):
		self.bus.write_word_data(self.device, 0b00000011, poweron)

	def setShutdownDelay(self, shutdown):
		self.bus.write_word_data(self.device, 0b00000100, shutdown)

	def getPowerOnDelay(self):
		return self.readWord(0b00000011)

	def getShutdownDelay(self):
		return self.readWord(0b00000100)

	def getFirmwareVersion(self):
		word = self.readWord(0b00001001) # 9
		return [word >> 8, word & 0xff]

	def getSerialNumber(self):
		return self.readWord(0b00001010) # 10

	def readWord(self, register):
		tries = 0
		data = 0xFFFF
		while data == 0xFFFF and tries < READTRIES:
			data = self.bus.read_word_data(self.device, register)
			tries += 1
		if data == 0xFFFF:
			raise Exception("Error reading register %i, expected non 0xFF value." % register)
		data = data & 32767 # fix for leading bit
		return data
			

def getApiVersion():
	return VERSION


class status():
	byte = 0

	def __init__(self, status):
		self.byte = status

	def getByte(self):
		return self.byte

	# get the bit, starting from 0 LSB
	def getBit(self, bitnum):
		return (self.byte & (1 << bitnum)) >> bitnum
	
	
	def SourceOneActive(self):
		return self.getBit(0)
	def SourceTwoActive(self):
		return self.getBit(1)

	def LEDBlue(self):
		return self.getBit(2)
	def LEDGreen(self):
		return self.getBit(3)
	def LEDRed(self):
		return self.getBit(4)
	def LEDFlashing(self):
		return self.getBit(5)
	
	def ForcedShutdown(self):
		return self.getBit(7)

	def PowerOnDelaySet(self):
		return self.getBit(8)
	def PowerOnDelayActive(self):
		return self.getBit(9)
	def ShutdownDelaySet(self):
		return self.getBit(10)
	def ShutdownDelayActive(self):
		return self.getBit(11)


	def StatusDetail(self):
		out = ""

		if self.SourceOneActive():
			out += 'Battery #1 active\n'
		if self.SourceTwoActive():
			out += 'Battery #2 active\n'

		if self.LEDBlue():
			out += 'Battery full (blue led)\n'
		if self.LEDGreen():
			out += 'Battery good (green led)\n'
		if self.LEDRed():
			out += 'Battery low (red led)\n'
		if self.LEDFlashing():
			out += 'Battery critical (flashing red led)\n'

		if self.ForcedShutdown():
			out += 'Forced shutdown\n'

		if self.PowerOnDelaySet():
			out += 'Power on delay set\n'
		if self.PowerOnDelayActive():
			out += 'Power on delay in progress\n'
		if self.ShutdownDelaySet():
			out += 'Shutdown delay set\n'
		if self.ShutdownDelayActive():
			out += 'Shutdown delay in progress\n'

		if out == "":
			out = "An error has occured"
		else:
			out = out[:-1]
		return out
